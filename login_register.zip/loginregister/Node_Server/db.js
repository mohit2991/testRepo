
const sql = require('mssql')


const config = {
    user: 'loginregister1',
    password: 'Lf7w-9?581z1',
    server: 'den1.mssql7.gear.host',
    database: 'loginregister1'

}


module.exports = {

    register: function (user, callback) {

        sql.connect(config).then(() => {
            console.log("Server connected");
            return sql.query`insert into Users values(${user.username}, ${user.firstName}, ${user.lastName}, ${user.password}, ${new Date()})`
        }).then(result => {
            sql.close();
            console.log("User regisered successfuly!");
            console.dir(result)
            callback(user);
        }).catch(err => {
            sql.close();
            console.log("Error in saving user data, ", err);
            callback(null, err);
        })

        sql.on('error', err => {
            sql.close();
            // ... error handler
            callback(null, err);
        })

    },

    login: function (user, callback) {


        sql.connect(config).then(() => {
            console.log("Server connected");
            return sql.query`select username, firstname, lastname from Users where username = ${user.username} and password = ${user.password}`
        }).then(result => {
            sql.close();
            console.log(result.rowsAffected)
            if (result.rowsAffected > 0) {
                console.log("User login successfuly!");
                let token = user.username + "###12345" + new Date();
                user["token"] = token;
                callback(user);
            }
            else {
                callback(null, { error: "Invalid username or password!" })
            }
        }).catch(err => {
            sql.close();
            console.log("Error in login user, ", err);
            callback(null, err);
        })

        sql.on('error', err => {
            sql.close();
            // ... error handler
            callback(null, err);
        })

    }

}
