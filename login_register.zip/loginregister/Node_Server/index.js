const express = require('express')
var db = require('./db');
const app = express();

app.use(express.json())

// Enabling Cors

app.use(function (req, res, next) {
    res.header("Access-Control-Allow-Origin", "*");
    res.header("Access-Control-Allow-Headers", "*");
    next();
});


//Adding routes

app.get('/', (req, res) => {
    res.send('Welcome!')
});

app.post('/login', (req, res) => {

    let user = {
        username: req.body.username,
        password: req.body.password
    }

    db.login(user, function (response, err) {
        if (response) {
            res.send(response)
        }
        else {
            return res.status(401).send(err);
        }
    });
});


app.post('/register', (req, res) => {
    let user = {

        username: req.body.username,
        password: req.body.password,
        firstName: req.body.firstName,
        lastName: req.body.lastName
    }
    db.register(user, function (response, err) {
        if (response) {
            res.send(response)
        }
        else {
            return res.status(400).send(err);
        }
    });
});

// app.get('/users', (req, res) => {
//     res.send(
//         [{
//             id: 2,
//             username: "user1@gmail.com",
//             password: "123456",
//             firstName: "User 1",
//             lastName: "Chauhan"
//         }
//         ]
//     )
// });


//App is listening on port 8000
app.listen(8000, () => {
    console.log('App listening on port 8000!')
});